cd DC
make clean
cd ../DX
make clean
cd ../DR
make clean