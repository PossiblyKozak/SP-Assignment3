cd DC
make
cd ../DX
make
cd ../DR
make